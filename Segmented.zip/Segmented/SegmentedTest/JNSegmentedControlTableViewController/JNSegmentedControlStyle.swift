import UIKit

// JNSegmentedControlStyle
enum JNSegmentedControlStyle: Int {
    
    case textOnly          = 0

    
    // Title
    var title: String {
        
        switch self {
        case .textOnly:
            return "Text Only"

        }
    }
}

// JNSegmentedControlViewController
class JNSegmentedControlTableViewController: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // set navigation controller title
        self.navigationItem.title = "JN Segmented Control Styles"
    }
}
