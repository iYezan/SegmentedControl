//
//  JNSegmentedControlDetailViewController.swift
//  JNSegmentedControl
//
//  Created by JNDisrupter on 11/29/18.
//  Copyright © 2018 JNDisrupter. All rights reserved.
//

import UIKit
import JNSegmentedControl

// JNSegmentedControlDetailViewController
class JNSegmentedControlDetailViewController: UIViewController {
    
    /// selected segmented style
    @IBOutlet weak var selectedSegmentedStyle: UILabel!
    
    /// Segmented Control View
    @IBOutlet weak var segmentedControlView: JNSegmentedCollectionView!
    
    /// Segmented Style
    var segmentedStyle: JNSegmentedControlStyle = JNSegmentedControlStyle.textOnly
    
    /// Text Array
    let textArray = ["Area Chart" , "Bar Chart" , "Line Chart", "Pie Chart", "Area Chart"]
    
    
    // array of attributed items
    var attributedStringItems: [NSAttributedString] = []
    var selectedAttributedStringItems: [NSAttributedString] = []
    
    // default attributes
    var defaultAttributes = [NSAttributedString.Key.font: UIFont.systemFont(ofSize: 16), NSAttributedString.Key.foregroundColor: UIColor.black]
    
    // selected attributes
    var selectedAttributes = [NSAttributedString.Key.font: UIFont.systemFont(ofSize: 16), NSAttributedString.Key.foregroundColor: UIColor(red: CGFloat(0), green: CGFloat(118.0/255.0), blue: CGFloat(192/255.0), alpha: CGFloat(1.0))]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // show segmented control view
        self.showSegmentedControlView()
        
        segmentedControlView.layer.cornerRadius = 10
        segmentedControlView.layer.borderWidth = 0.5
        
        segmentedControlView.layer.borderColor = UIColor.white.cgColor
        segmentedControlView.layer.shadowColor = UIColor.white.cgColor
        segmentedControlView.layer.shadowOpacity = 0.8
        segmentedControlView.layer.shadowRadius = 5.0
        segmentedControlView.layer.shadowOffset = CGSize(width: 0, height: 2.0)
        segmentedControlView.layer.masksToBounds = true
        
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        // set navigation controller title
        self.navigationItem.title = self.segmentedStyle.title
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        // listen to changing the status
        self.segmentedControlView.valueDidChange = { segmentIndex in
            self.selectedSegmentedStyle.text = "\(segmentIndex)"
        }
    }
    
    // showSegmentedControlView
    func showSegmentedControlView(){
        
        // setup segmented collection view
        switch self.segmentedStyle {
        case .textOnly:
            self.setupTextOnlySegmentedCollectionView()
            
        }
        
        // define vertical separator options
        let verticalSeparatorOptions = JNSegmentedCollectionItemVerticalSeparatorOptions(heigthRatio: 0.6, width: 1.0 ,color: UIColor(red: CGFloat(0), green: CGFloat(118.0/255.0), blue: CGFloat(192/255.0), alpha: CGFloat(1.0)))
        
        // define options
        let options = JNSegmentedCollectionOptions(backgroundColor: .clear, layoutType: JNSegmentedCollectionLayoutType.dynamic, verticalSeparatorOptions: verticalSeparatorOptions, scrollEnabled: true)
        
        // setup collection view
        self.segmentedControlView.setup(items: self.attributedStringItems, selectedItems: self.selectedAttributedStringItems, options: options)
    }
    
    // MARK: - Build Segmented Styles
    private func setupTextOnlySegmentedCollectionView(){
        
        // convert strings to attributed string
        for item in self.textArray {
            
            // Default Attributed String
            let defaultAttributedString = NSAttributedString(string: item, attributes: defaultAttributes)
            attributedStringItems.append(defaultAttributedString)
            
            // Selected Attributed string
            let selectedAttributedString = NSAttributedString(string: item, attributes: selectedAttributes)
            selectedAttributedStringItems.append(selectedAttributedString)
        }
    }
    
}
